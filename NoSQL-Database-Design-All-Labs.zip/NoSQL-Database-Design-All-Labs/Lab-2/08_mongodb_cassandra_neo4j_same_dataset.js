// MongoDB
db.Students.insertMany([{id:1,name:"Aman",course:"BCA"},{id:2,name:"Riya",course:"BCA"}]);
db.Students.find({course:"BCA"});
// Cassandra
// CREATE TABLE students (id int PRIMARY KEY, name text, course text);
// INSERT INTO students (id,name,course) VALUES (1,'Aman','BCA');
// SELECT * FROM students;
// Neo4j
// CREATE (:Student {id:1,name:'Aman'})-[:ENROLLED_IN]->(:Course {name:'BCA'});
// MATCH (s:Student)-[:ENROLLED_IN]->(c:Course) RETURN s,c;
