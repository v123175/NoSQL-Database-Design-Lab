use("CollegeDB");
db.StudentMarks.insertMany([
 {Student_ID:1,Name:"Aman",Course:"BCA",Marks:85},
 {Student_ID:2,Name:"Riya",Course:"BCA",Marks:91},
 {Student_ID:3,Name:"Kabir",Course:"BSc",Marks:78},
 {Student_ID:4,Name:"Neha",Course:"BCA",Marks:88},
 {Student_ID:5,Name:"Arjun",Course:"BSc",Marks:82}
]);
const mapFn=function(){emit(this.Course,{count:1,total:this.Marks});};
const reduceFn=function(key,values){return values.reduce((a,v)=>({count:a.count+v.count,total:a.total+v.total}),{count:0,total:0});};
db.StudentMarks.mapReduce(mapFn,reduceFn,{out:"course_summary"});
db.course_summary.find().forEach(x=>printjson({course:x._id,count:x.value.count,average:x.value.total/x.value.count}));
