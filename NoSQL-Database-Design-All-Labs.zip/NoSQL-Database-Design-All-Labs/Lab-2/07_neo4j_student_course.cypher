UNWIND [{id:1,name:'Aman'},{id:2,name:'Riya'},{id:3,name:'Kabir'},{id:4,name:'Neha'},{id:5,name:'Arjun'}] AS x
MERGE (:Student {id:x.id,name:x.name});
UNWIND ['BCA','BSc','BCom'] AS c MERGE (:Course {name:c});
MATCH (s:Student {id:1}),(c:Course {name:'BCA'}) MERGE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:2}),(c:Course {name:'BCA'}) MERGE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:3}),(c:Course {name:'BSc'}) MERGE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:4}),(c:Course {name:'BCA'}) MERGE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:5}),(c:Course {name:'BSc'}) MERGE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student) RETURN s;
MATCH (s:Student)-[:ENROLLED_IN]->(:Course {name:'BCA'}) RETURN s;
MATCH (:Student {name:'Aman'})-[:ENROLLED_IN]->(c:Course) RETURN c;
MATCH (s:Student {id:1}),(c:Course {name:'BSc'}) MERGE (s)-[:ENROLLED_IN]->(c);
MATCH (:Student {id:1})-[r:ENROLLED_IN]->(:Course {name:'BSc'}) DELETE r;
