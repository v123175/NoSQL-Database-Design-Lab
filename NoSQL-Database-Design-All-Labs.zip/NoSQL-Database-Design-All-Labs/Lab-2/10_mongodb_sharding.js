// Run on mongos after configuring config servers and shard replica sets.
sh.enableSharding("CollegeDB");
sh.shardCollection("CollegeDB.students",{student_id:"hashed"});
use("CollegeDB");
for (let i=1;i<=20;i++) db.students.insertOne({student_id:i,name:"Student"+i,marks:60+i});
db.students.getShardDistribution();
