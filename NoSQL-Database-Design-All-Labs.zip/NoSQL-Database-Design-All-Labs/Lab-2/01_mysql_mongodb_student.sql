-- MySQL
CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;
CREATE TABLE Student (
  Student_ID INT PRIMARY KEY, Name VARCHAR(60), Course VARCHAR(40),
  Semester INT, Marks DECIMAL(5,2)
);
INSERT INTO Student VALUES
(1,'Aman','BCA',2,85),(2,'Riya','BCA',2,91),(3,'Kabir','BSc',3,78),
(4,'Neha','BCA',4,88),(5,'Arjun','BSc',3,82);
SELECT * FROM Student;

-- MongoDB mongosh equivalent
use CollegeDB
db.Students.insertMany([
 {Student_ID:1,Name:"Aman",Course:"BCA",Semester:2,Marks:85},
 {Student_ID:2,Name:"Riya",Course:"BCA",Semester:2,Marks:91},
 {Student_ID:3,Name:"Kabir",Course:"BSc",Semester:3,Marks:78},
 {Student_ID:4,Name:"Neha",Course:"BCA",Semester:4,Marks:88},
 {Student_ID:5,Name:"Arjun",Course:"BSc",Semester:3,Marks:82}
])
db.Students.find()
