# Start three mongod instances with --replSet rs0 on ports 27017, 27018, 27019.
# Connect: mongosh --port 27017
rs.initiate({_id:"rs0",members:[{_id:0,host:"localhost:27017"},{_id:1,host:"localhost:27018"},{_id:2,host:"localhost:27019"}]});
use("CollegeDB");
db.replication.insertOne({message:"replicated record"});
rs.status();
