// Configure two shard replica sets and a mongos router first.
sh.addShard("shard1/localhost:27117,localhost:27118");
sh.addShard("shard2/localhost:27217,localhost:27218");
sh.enableSharding("CollegeDB");
sh.shardCollection("CollegeDB.students",{student_id:"hashed"});
use("CollegeDB");
for(let i=1;i<=50;i++) db.students.insertOne({student_id:i,name:"Student"+i});
db.students.getShardDistribution();
