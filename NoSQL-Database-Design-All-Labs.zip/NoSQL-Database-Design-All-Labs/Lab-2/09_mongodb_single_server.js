// Start mongod separately, then run with mongosh.
use("SingleServerDB");
db.records.insertMany([{id:1,name:"Aman"},{id:2,name:"Riya"}]);
db.records.find();
db.records.updateOne({id:1},{$set:{name:"Aman Kumar"}});
db.records.deleteOne({id:2});
db.records.find();
