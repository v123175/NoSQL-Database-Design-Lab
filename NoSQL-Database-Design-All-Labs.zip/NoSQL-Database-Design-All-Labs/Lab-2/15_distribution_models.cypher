// Single server: one database instance stores all records.
// Sharding: partition records by shard key across servers.
// Primary-secondary: writes go to primary; secondaries replicate its oplog.
// Peer-to-peer: Cassandra nodes accept requests and coordinate replicas.
// Sharding + replication: each shard is a replica set.
// Example Neo4j graph representation:
CREATE (:Architecture {name:"Single Server",advantage:"Simple",limitation:"Single point of failure",application:"Small application"});
CREATE (:Architecture {name:"Sharding",advantage:"Horizontal scale",limitation:"Shard-key design complexity",application:"Large datasets"});
CREATE (:Architecture {name:"Primary-Secondary",advantage:"Read redundancy",limitation:"Primary write dependency",application:"Transactional workloads"});
CREATE (:Architecture {name:"Peer-to-Peer",advantage:"No single master",limitation:"Consistency tuning",application:"Distributed services"});
CREATE (:Architecture {name:"Sharding + Replication",advantage:"Scale and fault tolerance",limitation:"Operational complexity",application:"Large production systems"});
