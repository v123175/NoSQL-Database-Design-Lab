use("CollegeDB");
db.Reviews.insertMany([
 {product_id:1,user:"Aman",rating:5,review:"Excellent"},
 {product_id:1,user:"Riya",rating:4,review:"Good"},
 {product_id:2,user:"Kabir",rating:3,review:"Average"}
]);
db.Reviews.aggregate([{$group:{_id:"$product_id",averageRating:{$avg:"$rating"},reviewCount:{$sum:1}}}]);
