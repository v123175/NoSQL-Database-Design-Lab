use("CollegeDB");
db.Notifications.insertMany([
 {user:"Aman",message:"New message",type:"message",read:false},
 {user:"Aman",message:"Order shipped",type:"order",read:false},
 {user:"Riya",message:"System update",type:"system",read:true}
]);
db.Notifications.find({user:"Aman",read:false});
db.Notifications.updateMany({user:"Aman",read:false},{$set:{read:true,readAt:new Date()}});
