use("CollegeDB");
db.Carts.insertOne({user_id:1,items:[{product_id:101,name:"Mouse",qty:1,price:500}]});
db.Carts.updateOne({user_id:1},{$push:{items:{product_id:102,name:"Keyboard",qty:1,price:900}}});
db.Carts.updateOne({user_id:1,"items.product_id":101},{$inc:{"items.$.qty":2}});
db.Carts.updateOne({user_id:1},{$pull:{items:{product_id:102}}});
db.Carts.aggregate([{$match:{user_id:1}},{$project:{total:{$sum:{$map:{input:"$items",as:"i",in:{$multiply:["$$i.qty","$$i.price"]}}}}}}]);
