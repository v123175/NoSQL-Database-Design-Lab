use("CollegeDB");
db.PageVisits.insertMany([
 {page:"/home",user_id:1,device:"mobile",browser:"Chrome",location:"India",timestamp:new Date()},
 {page:"/home",user_id:2,device:"desktop",browser:"Firefox",location:"India",timestamp:new Date()},
 {page:"/products",user_id:3,device:"mobile",browser:"Chrome",location:"India",timestamp:new Date()}
]);
db.PageVisits.aggregate([{$group:{_id:"$page",visits:{$sum:1}}},{$sort:{visits:-1}}]);
db.PageVisits.aggregate([{$group:{_id:"$device",uses:{$sum:1}}},{$sort:{uses:-1}}]);
