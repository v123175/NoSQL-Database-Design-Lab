use("CollegeDB");
db.StudentActivity.insertMany([
 {student_id:1,name:"Aman",courses:["DBMS","Python"],attendance:90,skills:["Java","SQL"],activities:[{type:"login",date:new Date()},{type:"quiz",score:9}]},
 {student_id:2,name:"Riya",courses:["DBMS"],attendance:75,skills:["Python"],activities:[{type:"login",date:new Date()}]}
]);
db.StudentActivity.find({attendance:{$gte:80}});
db.StudentActivity.find({"activities.type":"quiz"});
db.StudentActivity.find({skills:"Python"});
