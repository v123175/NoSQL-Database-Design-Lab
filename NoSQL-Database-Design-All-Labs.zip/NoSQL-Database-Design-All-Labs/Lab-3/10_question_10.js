use("CollegeDB");
db.Inventory.insertMany([
 {product:"Mouse",stock:5,min_stock:10,supplier:"ABC",restock_date:new Date()},
 {product:"Laptop",stock:20,min_stock:5,supplier:"XYZ",restock_date:new Date()}
]);
db.Inventory.find({$expr:{$lte:["$stock","$min_stock"]}});
