use("CollegeDB");
db.Courses.insertOne({course_id:1,title:"NoSQL",instructor:"Dr Rao",modules:["Intro","MongoDB","Aggregation"]});
db.LearningProgress.insertMany([
 {student:"Aman",course_id:1,progress:80,completed:false},
 {student:"Riya",course_id:1,progress:100,completed:true}
]);
db.LearningProgress.find({course_id:1,progress:{$gte:75}});
db.LearningProgress.find({completed:true});
