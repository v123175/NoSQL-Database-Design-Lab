use("CollegeDB");
db.News.insertMany([
 {title:"Tech News",author:"Aman",location:"Delhi",category:"Technology",tags:["AI"],images:[],sources:["NewsDesk"]},
 {title:"City Update",location:"Roorkee",category:"Local",tags:["city"],sources:["Reporter"]},
 {title:"Sports",author:"Riya",category:"Sports",images:["sports.jpg"]}
]);
db.News.find({$or:[{author:"Aman"},{location:"Roorkee"},{tags:"AI"}]});
db.News.find({category:"Sports"});
