use("CollegeDB");
db.Customers.insertMany([{customer_id:1,name:"Aman"},{customer_id:2,name:"Riya"}]);
db.Products.insertMany([{product_id:1,name:"Mouse",price:500},{product_id:2,name:"Keyboard",price:900}]);
db.Orders.insertMany([
 {order_id:1,customer_id:1,items:[{product_id:1,qty:2,price:500},{product_id:2,qty:1,price:900}]},
 {order_id:2,customer_id:2,items:[{product_id:2,qty:1,price:900}]}
]);
db.Orders.aggregate([{$match:{customer_id:1}},{$addFields:{total:{$sum:{$map:{input:"$items",as:"i",in:{$multiply:["$$i.qty","$$i.price"]}}}}}}]);
