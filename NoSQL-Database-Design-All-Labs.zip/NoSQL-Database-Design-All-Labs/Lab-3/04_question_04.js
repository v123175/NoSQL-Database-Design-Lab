use("CollegeDB");
db.Products.insertMany([
 {name:"Laptop A",category:"laptop",ram:16,storage:512,cpu:"i5"},
 {name:"Phone A",category:"mobile",camera:50,battery:5000,os:"Android"},
 {name:"Camera A",category:"camera",megapixels:24,lens:"18-55"},
 {name:"Laptop B",category:"laptop",ram:8,storage:256,cpu:"i3"}
]);
db.Products.find({category:"laptop",ram:{$gte:8}});
db.Products.find({category:"mobile",battery:{$gte:4500}});
db.Products.find({category:"camera",megapixels:{$gte:20}});
