use("CollegeDB");
db.Articles.insertMany([
 {title:"Published A",author:"Aman",category:"DB",tags:["nosql"],status:"published",createdAt:new Date()},
 {title:"Draft B",author:"Riya",category:"Tech",tags:["mongo"],status:"draft",createdAt:new Date()}
]);
db.Articles.find({status:"published"});
db.Articles.find({status:"draft",category:"Tech"});
db.Articles.updateOne({title:"Draft B"},{$set:{status:"published"}});
