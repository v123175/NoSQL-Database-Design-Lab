use("CollegeDB");
db.OrderTracking.insertOne({order_id:1001,current_status:"Placed",history:[{status:"Placed",at:new Date()}]});
db.OrderTracking.updateOne({order_id:1001},{$set:{current_status:"Confirmed"},$push:{history:{status:"Confirmed",at:new Date()}}});
db.OrderTracking.updateOne({order_id:1001},{$set:{current_status:"Shipped"},$push:{history:{status:"Shipped",at:new Date()}}});
db.OrderTracking.findOne({order_id:1001},{current_status:1,history:1});
