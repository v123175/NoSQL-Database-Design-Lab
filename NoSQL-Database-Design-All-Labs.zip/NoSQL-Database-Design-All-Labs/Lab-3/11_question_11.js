// Run on a MongoDB replica set or sharded cluster to support transactions.
const session=db.getMongo().startSession();
const sdb=session.getDatabase("CollegeDB");
try {
 session.startTransaction();
 sdb.Wallets.updateOne({user:"Aman",balance:{$gte:500}},{$inc:{balance:-500}});
 sdb.Wallets.updateOne({user:"Riya"},{$inc:{balance:500}});
 session.commitTransaction();
} catch(e) { session.abortTransaction(); throw e; }
finally { session.endSession(); }
