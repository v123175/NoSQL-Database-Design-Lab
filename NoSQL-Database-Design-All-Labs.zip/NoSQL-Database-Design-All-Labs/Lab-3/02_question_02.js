use("CollegeDB");
db.EventLogs.insertMany([
 {user:"aman",event:"login",time:new Date()},
 {user:"aman",event:"failed-login",time:new Date()},
 {user:"aman",event:"failed-login",time:new Date()},
 {user:"riya",event:"file-upload",time:new Date()},
 {user:"aman",event:"logout",time:new Date()},
 {user:"riya",event:"password-change",time:new Date()}
]);
db.EventLogs.aggregate([{$match:{event:"failed-login"}},{$group:{_id:"$user",attempts:{$sum:1}}},{$match:{attempts:{$gte:2}}}]);
db.EventLogs.aggregate([{$group:{_id:"$event",count:{$sum:1}}},{$sort:{count:-1}}]);
