use("CollegeDB");
db.Blogs.insertMany([
 {title:"NoSQL Intro",author:"Aman",category:"DB",tags:["nosql","database"],comments:[],published:true,publishedAt:new Date()},
 {title:"Mongo Tips",author:"Riya",category:"DB",tags:["mongodb","database"],comments:[{by:"Aman",text:"Nice"}],published:true,publishedAt:new Date()},
 {title:"Travel",author:"Kabir",category:"Life",tags:["travel"],comments:[],published:false}
]);
db.Blogs.find({tags:"database",category:"DB"});
db.Blogs.find({tags:{$all:["mongodb","database"]}});
