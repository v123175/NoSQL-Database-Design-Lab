NO SQL DATABASE DESIGN LAB ANSWERS
Lab-2: MySQL, MongoDB, Redis, Cassandra, HBase, Neo4j and distribution models.
Lab-3: MongoDB solutions for all 15 questions.
Lab-4: HBase and Cassandra solutions for all 15 questions.
Lab-5: Riak KV and Neo4j solutions, if included from the previous bundle.
Run each file with the matching database shell/client. Configure database services first.
